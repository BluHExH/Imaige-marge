# Danger Stego Tool

Powerful and stylish steganography tool made for Termux by Hacker Hex 🔥

## Features

- 🔐 Embed any file inside a JPG image
- 🔓 Extract files easily
- 🧠 Password protected
- 🎨 HEX-style banner

## Usage

```bash
bash danger.sh
```

## License

MIT © Hacker Hex
